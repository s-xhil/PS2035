<html>

 <body>
Welcome to our homepage: 
<?php echo $_SERVER['HTTP_HOST'];?>
wow!
 </body>
</html>

